# Roblox Cookie Stealer - C# Version

This C# script retrieves certain details of a Roblox account by obtaining the `.ROBLOSECURITY` cookie, allowing authentication and extraction of account information. The script sends the details of a logged-in Roblox account to a Discord webhook.

## Usage

- Open Project 
- Type your own Webhook Address in the `YOUR_WEBHOOK` section.
- Compile the project.
- The script utilizes browser cookies to automatically extract the `.ROBLOSECURITY` cookie. Ensure that you are logged into your Roblox account in the browser.
- By executing the script, you can check the validity of the cookie and send information about the cookie, IP address, and Roblox account to a Discord webhook.


# Features

- **No Console:** Provides a seamless user experience without a console interface.
- **No Errors:** Provides a robust performance by eliminating errors and glitches.
- **Error-Free Execution:** It runs smoothly without encountering any errors during operation.
- **Comprehensive Roblox Account Details:** Collects all information about the Roblox account and sends it to the designated webhook.


## Important Notes

- Exercise caution while using this script as user privacy and security are paramount.
- Users are solely responsible for any issues arising from the use of this script.

## Contributing

If you wish to work on or contribute to this script, feel free to submit a request for discussion and contribution.

## License

This script has not been published under a specific license. Consider licensing before integrating it into your own project.
